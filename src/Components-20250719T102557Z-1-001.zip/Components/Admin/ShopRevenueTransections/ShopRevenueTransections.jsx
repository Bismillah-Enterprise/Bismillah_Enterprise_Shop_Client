import React from 'react';

const ShopRevenueTransections = () => {
    return (
        <div>
            
        </div>
    );
};

export default ShopRevenueTransections;